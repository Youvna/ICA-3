function setup() {
  createCanvas(360, 400);
}

function draw() {
  background(51, 48, 48);
  
  noStroke()
  fill(196, 152, 29)
  arc(200, 255, 200, 200, -PI, 0, CHORD);  // Taco back

  fill(59, 117, 55)
  ellipse(270, 260, 100, 20)               // Leaf1 (right)

  fill(107, 161, 103)
  arc(270, 255, 100, 20, -PI, 0, CHORD);   // Leaf2 (right)

  fill(181, 77, 22)
  ellipse(210, 180, 60, 40)                // Sausage1 (top, back)
  ellipse(270, 240, 80, -40)               // Sausage2 (right)
  fill(194, 101, 47)
  circle(230, 190, 50)                     // Sausage3 (top, front)

  fill(177, 217, 145)
  ellipse(130, 230, 160, 20)               // Leaf3 (left)

  fill(59, 117, 55)
  ellipse(130, 200, 190, 50)               // Leaf4 (left)

  fill(181, 77, 22)
  circle(120, 210, 90)                     // Paty1 (left, back)
  fill(194, 101, 47)
  circle(130, 190, 70)                     // Paty2 (left, front)

  fill(219, 218, 200)
  arc(250, 228, 100, 20, -PI, 0, CHORD);    // Amul cheese (right)
  arc(160, 200, 100, 70, -PI, 0, CHORD);    // Go cheese (left)

  fill(224, 181, 58)
  arc(180, 270, 200, 200, -PI, 0, CHORD);   // Taco front

}